export { default as CurriculumDesignerContainer } from './CurriculumDesignerContainer';
