import { CurriculumDesignerContainer } from '@container/CurriculumDesigner';

export default function CurriculumDesigner() {
  return <CurriculumDesignerContainer />;
}
