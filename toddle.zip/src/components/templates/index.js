export { default as CurriculumDesignerTemplate } from './CurriculumDesignerTemplate';
