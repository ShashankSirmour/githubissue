import { colors } from '@mui/material';

export default {
  root: {
    backgroundColor: colors.grey[50],
  },
};
